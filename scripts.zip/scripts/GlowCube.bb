# GlowCube.bb - Neon Hyperspace Cube
SYSTEM.APPNAME "Hyperspace"

LET ay = 0.0
LET ax = 15.0
LET scan_y = 0.0

# Star positions (computed once at init)
Math.Random 10, 390
LET s0x = result
Math.Random 10, 290
LET s0y = result
Math.Random 10, 390
LET s1x = result
Math.Random 10, 290
LET s1y = result
Math.Random 10, 390
LET s2x = result
Math.Random 10, 290
LET s2y = result
Math.Random 10, 390
LET s3x = result
Math.Random 10, 290
LET s3y = result
Math.Random 10, 390
LET s4x = result
Math.Random 10, 290
LET s4y = result
Math.Random 10, 390
LET s5x = result
Math.Random 10, 290
LET s5y = result
Math.Random 10, 390
LET s6x = result
Math.Random 10, 290
LET s6y = result
Math.Random 10, 390
LET s7x = result
Math.Random 10, 290
LET s7y = result

:onUpdate
  LET ay = ((ay + (21.0 * delta_time)) % 360.0)
  LET ax = ((ax + (9.0 * delta_time)) % 360.0)
  LET scan_y = ((scan_y + (45.0 * delta_time)) % 270.0)
RETURN

:onDraw
  Graphics.FillRect 0, 0, 396, 300, BLACK

  # Twinkling starfield (smooth sine-based)
  LET blink_val = ((ay * 3.0) % 360.0)
  Math.Sin blink_val
  LET blink = (result * 2.0)
  
  Graphics.FillCircle s0x, s0y, 1, WHITE
  Graphics.FillCircle s1x, s1y, 1, GRAY
  Graphics.FillCircle s2x, s2y, 1, WHITE
  Graphics.FillCircle s3x, s3y, 1, DARKGRAY
  Graphics.FillCircle s4x, s4y, 1, CYAN
  Graphics.FillCircle s5x, s5y, 1, WHITE
  Graphics.FillCircle s6x, s6y, 1, GRAY
  Graphics.FillCircle s7x, s7y, 1, WHITE
  IF blink > 0.0 THEN
    Graphics.FillCircle s2x, s2y, 2, CYAN
    Graphics.FillCircle s5x, s5y, 2, WHITE
  ENDIF

  # Multi-layered neon cubes
  3D.DrawCube 200, 135, 80, ay, ax, NAVY, NAVY, NAVY
  3D.DrawCube 200, 135, 74, ay, ax, TEAL, NAVY, NAVY
  3D.DrawCube 200, 135, 68, ay, ax, DARKGRAY, DARKGRAY, TEAL
  3D.DrawCube 200, 135, 60, ay, ax, CYAN, GREEN, MAGENTA
  3D.DrawCube 200, 135, 35, ay, ax, WHITE, CYAN, BLUE

  # Center dot pulse
  Graphics.FillCircle 200, 135, (3.0 + blink), CYAN
 
  # Scan line effect
  Graphics.DrawLine 0, scan_y, 396, scan_y, NAVY

  # UI Overlay
  Graphics.DrawProportional 85, 8, "HYPERSPACE", CYAN, 0, 0.6
  Graphics.FillRect 0, 272, 396, 28, NAVY
  Graphics.DrawLine 0, 272, 396, 272, CYAN
  Graphics.DrawProportional 10, 272, "HYPERSPACE CORE | STABLE", SILVER, 0, 0.6

  SYSTEM.TOP
  Graphics.DrawString 8, 280, "3D.DrawCube // HW ACCEL", CYAN
  Graphics.DrawString 270, 280, ("HEAP:" + mem_free), DARKGRAY
RETURN
