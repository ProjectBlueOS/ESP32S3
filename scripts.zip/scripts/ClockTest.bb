# ClockTest.bb - Neon Digital Horizon v2.0
SYSTEM.APPNAME "Neon Horizon"

# Initialize colors and state
LET bg_rot_x = 0
LET bg_rot_y = 0
LET cube_size = 80

:onUpdate
  # Update rotation for next frame
  LET bg_rot_x = ((bg_rot_x + (delta_time * 20)) % 360.0)
  LET bg_rot_y = ((bg_rot_y + (delta_time * 35)) % 360.0)
RETURN

:onDraw
  Graphics.FillRect 0, 0, 396, 318, BLACK
  
  # Draw dynamic 3D background
  # 3D.DrawCube cx, cy, size, angY, angX, frontCol, backCol, edgeCol
  3D.DrawCube 200, 140, cube_size, bg_rot_y, bg_rot_x, NAVY, YELLOW, TEAL

  SYSTEM.GETTIME

  # Big neon time display
  # Add leading zeros logic
  LET h_str = hour
  IF hour < 10 THEN
    LET h_str = "0" + hour
  ENDIF
  LET m_str = minute
  IF minute < 10 THEN
    LET m_str = "0" + minute
  ENDIF
  LET s_str = second
  IF second < 10 THEN
    LET s_str = "0" + second
  ENDIF

  LET ts1 = h_str + ":"
  LET ts2 = ts1 + m_str
  LET ts3 = ts2 + ":"
  LET ts = ts3 + s_str
  
  # Draw Glow / Shadow
  Graphics.DrawProportional 57, 82, ts, PURPLE, 0, 1.5
  Graphics.DrawProportional 55, 80, ts, WHITE, 0, 1.5

  # Date with neon accent
  LET ds1 = day + " / "
  LET ds2 = ds1 + month
  LET ds3 = ds2 + " / "
  LET ds = ds3 + year
  Graphics.DrawProportional 112, 172, ds, NAVY, 0, 0.7
  Graphics.DrawProportional 110, 170, ds, CYAN, 0, 0.7

  # System Stats
  SYSTEM.TOP
  LET s_up1 = "UPTIME: " + uptime
  LET s_up = s_up1 + "s"
  Graphics.DrawString 20, 240, s_up, GREEN

  LET ps_kb = (psram_free / 1024)
  LET s_ps1 = "PSRAM : " + ps_kb
  LET s_ps = s_ps1 + " KB FREE"
  Graphics.DrawString 20, 260, s_ps, GREEN

  LET s_ld1 = "LOAD  : " + cpu_load
  LET s_ld = s_ld1 + "%"
  Graphics.DrawString 220, 240, s_ld, ORANGE

  LET mem_kb = (mem_free / 1024)
  LET s_mem1 = "SRAM  : " + mem_kb
  LET s_mem = s_mem1 + " KB FREE"
  Graphics.DrawString 220, 260, s_mem, CYAN

  # Footer glow line
  Graphics.DrawLine 20, 280, 380, 280, MAGENTA
  Graphics.DrawLine 20, 281, 380, 281, PURPLE
RETURN
