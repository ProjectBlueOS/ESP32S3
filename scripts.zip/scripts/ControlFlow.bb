# ControlFlow.bb - Board Diagnostics Monitor
SYSTEM.APPNAME "Monitor Pro"

LET ticker = 0.0
LET do_ping = 0
 
:onUpdate
  LET ticker = ((ticker + delta_time) % 6.0)
  IF ticker < delta_time THEN
    LET do_ping = 1
  ENDIF
RETURN

:onDraw
  Graphics.FillRect 0, 0, 396, 300, BLACK

  # Header
  Graphics.FillRect 0, 0, 396, 36, NAVY
  Graphics.DrawProportional 10, 6, "BOARD DIAGNOSTICS", WHITE, 0, 0.8

  # System stats
  SYSTEM.TOP
  LET s_heap1 = "HEAP:  " + mem_free
  LET s_heap = s_heap1 + " B"
  Graphics.DrawString 20, 50, s_heap, CYAN

  LET s_psram1 = "PSRAM: " + psram_free
  LET s_psram = s_psram1 + " B"
  Graphics.DrawString 20, 70, s_psram, CYAN

  LET s_tasks = "TASKS: " + tasks_count
  Graphics.DrawString 20, 90, s_tasks, CYAN

  # Chip & uptime
  System.GetChipType
  System.GetUptime
  LET s_chip = "CHIP:   " + chip_type
  Graphics.DrawString 20, 120, s_chip, WHITE

  LET s_up1 = "UPTIME: " + uptime
  LET s_up = s_up1 + "s"
  Graphics.DrawString 20, 140, s_up, WHITE

  # Network panel
  Network.IsConnected
  IF net_connected = 1 THEN
    Network.GetIP
    Graphics.DrawString 220, 50, "NET: ONLINE", GREEN
    LET s_ip = "IP:  " + net_ip
    Graphics.DrawString 220, 70, s_ip, CYAN
  ELSE
    Graphics.DrawString 220, 50, "NET: OFFLINE", RED
  ENDIF

  IF do_ping = 1 THEN
    SYSTEM.PING "8.8.8.8"
    LET do_ping = 0
  ENDIF

  IF ping_success = 1 THEN
    LET s_ping1 = "PING: " + ping_ms
    LET s_ping = s_ping1 + " ms"
    Graphics.DrawString 220, 90, s_ping, GREEN
  ELSE
    Graphics.DrawString 220, 90, "PING: ---", DARKGRAY
  ENDIF

  # Storage
  SYSTEM.DIR "/sdcard/"
  LET s_files = "FILES: " + file_count
  Graphics.DrawString 220, 120, s_files, WHITE

  # Animated load bar
  Graphics.DrawString 10, 180, "LOAD", CYAN
  Graphics.FillRect 60, 180, 320, 14, DARKGRAY
  LET bw = (ticker * 53.3)
  IF bw > 320 THEN
    LET bw = 320
  ENDIF
  Graphics.FillRect 60, 180, bw, 14, GREEN

  # Temperature
  System.GetCpuTemp
  LET s_temp1 = "TEMP: " + cpu_temp
  LET s_temp = s_temp1 + " C"
  Graphics.DrawString 20, 210, s_temp, ORANGE

  # Footer
  SYSTEM.GETTIME
  LET s_time1 = hour + ":"
  LET s_time2 = s_time1 + minute
  LET s_time3 = s_time2 + ":"
  LET s_time = s_time3 + second
  Graphics.DrawString 60, 275, s_time, DARKGRAY

  LET s_date1 = day + "/"
  LET s_date2 = s_date1 + month
  LET s_date3 = s_date2 + "/"
  LET s_date = s_date3 + year
  Graphics.DrawString 230, 275, s_date, DARKGRAY
RETURN
