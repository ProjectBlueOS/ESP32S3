SYSTEM.APPNAME "Test"

LET x = 230
LET y = 100

IF x > 220 THEN
  IF x < 360 THEN
    IF y > 90 THEN
      IF y < 190 THEN
        PRINT "HIT!"
      ENDIF
    ENDIF
  ENDIF
ENDIF

END
