# AnalogClock.bb - Grand Horologist
# A refined analog timepiece with a luxury aesthetic
# Uses win_w and win_h for dynamic sizing
SYSTEM.APPNAME "Grand Horologist"

# Smooth second-hand animation
LET pulse = 0.0

:onUpdate
  SYSTEM.GETTIME
  LET pulse = ((pulse + (120.0 * delta_time)) % 360.0)
RETURN

:onDraw
  # Dynamic layout based on actual window size
  LET ww = win_w
  LET wh = win_h
  LET cx = (ww / 2)
  LET cy = ((wh - 40) / 2)
  LET radius = (cy - 15)
  IF radius > ((ww / 2) - 15) THEN
    LET radius = ((ww / 2) - 15)
  ENDIF
  IF radius > 110 THEN
    LET radius = 110
  ENDIF

  # Pre-calculate radii
  LET r_outer = radius
  LET r_bezel = (radius - 5)
  LET r_inner = (radius - 8)
  LET r_face = (radius - 10)
  LET r_tick_out = (r_face - 2)
  LET r_tick_in = (r_face - 14)
  LET r_num = (r_face - 22)
  LET r_dot = (r_face - 20)
  LET r_hour = (radius * 0.4)
  LET r_min = (radius * 0.6)
  LET r_sec = (radius * 0.7)
  LET bar_y = (wh - 38)

  # === BACKGROUND ===
  Graphics.FillRect 0, 0, ww, wh, BLACK

  # Subtle radial decoration
  Graphics.DrawCircle cx, cy, (r_outer + 10), 0x0841
  Graphics.DrawCircle cx, cy, (r_outer + 5), NAVY

  # === OUTER BEZEL: Double gold ring ===
  Graphics.DrawCircle cx, cy, r_outer, DARKGRAY
  Graphics.DrawCircle cx, cy, (r_outer - 1), GOLD
  Graphics.DrawCircle cx, cy, (r_outer - 2), GOLD
  Graphics.DrawCircle cx, cy, (r_outer - 3), DARKGRAY
  Graphics.DrawCircle cx, cy, r_bezel, DARKGRAY
  Graphics.DrawCircle cx, cy, (r_bezel - 1), SILVER
  Graphics.DrawCircle cx, cy, (r_bezel - 2), SILVER
  Graphics.DrawCircle cx, cy, r_inner, DARKGRAY

  # === FACE BACKGROUND ===
  Graphics.FillCircle cx, cy, r_face, 0x0841

  # === HOUR TICK MARKS ===
  # 12 o'clock
  Graphics.DrawLine cx, (cy - r_tick_out), cx, (cy - r_tick_in), SILVER
  # 3 o'clock
  Graphics.DrawLine (cx + r_tick_in), cy, (cx + r_tick_out), cy, SILVER
  # 6 o'clock
  Graphics.DrawLine cx, (cy + r_tick_in), cx, (cy + r_tick_out), SILVER
  # 9 o'clock
  Graphics.DrawLine (cx - r_tick_out), cy, (cx - r_tick_in), cy, SILVER

  # 1 o'clock
  Math.Sin 30
  LET tx1 = (cx + result * r_tick_out)
  LET tx2 = (cx + result * r_tick_in)
  Math.Cos 30
  LET ty1 = (cy - result * r_tick_out)
  LET ty2 = (cy - result * r_tick_in)
  Graphics.DrawLine tx1, ty1, tx2, ty2, SILVER

  # 2 o'clock
  Math.Sin 60
  LET tx1 = (cx + result * r_tick_out)
  LET tx2 = (cx + result * r_tick_in)
  Math.Cos 60
  LET ty1 = (cy - result * r_tick_out)
  LET ty2 = (cy - result * r_tick_in)
  Graphics.DrawLine tx1, ty1, tx2, ty2, SILVER

  # 4 o'clock
  Math.Sin 120
  LET tx1 = (cx + result * r_tick_out)
  LET tx2 = (cx + result * r_tick_in)
  Math.Cos 120
  LET ty1 = (cy - result * r_tick_out)
  LET ty2 = (cy - result * r_tick_in)
  Graphics.DrawLine tx1, ty1, tx2, ty2, SILVER

  # 5 o'clock
  Math.Sin 150
  LET tx1 = (cx + result * r_tick_out)
  LET tx2 = (cx + result * r_tick_in)
  Math.Cos 150
  LET ty1 = (cy - result * r_tick_out)
  LET ty2 = (cy - result * r_tick_in)
  Graphics.DrawLine tx1, ty1, tx2, ty2, SILVER

  # 7 o'clock
  Math.Sin 210
  LET tx1 = (cx + result * r_tick_out)
  LET tx2 = (cx + result * r_tick_in)
  Math.Cos 210
  LET ty1 = (cy - result * r_tick_out)
  LET ty2 = (cy - result * r_tick_in)
  Graphics.DrawLine tx1, ty1, tx2, ty2, SILVER

  # 8 o'clock
  Math.Sin 240
  LET tx1 = (cx + result * r_tick_out)
  LET tx2 = (cx + result * r_tick_in)
  Math.Cos 240
  LET ty1 = (cy - result * r_tick_out)
  LET ty2 = (cy - result * r_tick_in)
  Graphics.DrawLine tx1, ty1, tx2, ty2, SILVER

  # 10 o'clock
  Math.Sin 300
  LET tx1 = (cx + result * r_tick_out)
  LET tx2 = (cx + result * r_tick_in)
  Math.Cos 300
  LET ty1 = (cy - result * r_tick_out)
  LET ty2 = (cy - result * r_tick_in)
  Graphics.DrawLine tx1, ty1, tx2, ty2, SILVER

  # 11 o'clock
  Math.Sin 330
  LET tx1 = (cx + result * r_tick_out)
  LET tx2 = (cx + result * r_tick_in)
  Math.Cos 330
  LET ty1 = (cy - result * r_tick_out)
  LET ty2 = (cy - result * r_tick_in)
  Graphics.DrawLine tx1, ty1, tx2, ty2, SILVER

  # === HOUR NUMERALS ===
  Graphics.DrawProportional (cx - 6), (cy - r_num), "12", GOLD, 0, 0.4
  Math.Sin 30
  LET nx = (cx + result * r_num)
  Math.Cos 30
  LET ny = (cy - result * r_num)
  Graphics.DrawProportional nx, ny, "1", GOLD, 0, 0.35

  Math.Sin 60
  LET nx = (cx + result * r_num)
  Math.Cos 60
  LET ny = (cy - result * r_num)
  Graphics.DrawProportional nx, ny, "2", GOLD, 0, 0.35

  Graphics.DrawProportional (cx + r_num), (cy - 5), "3", GOLD, 0, 0.4

  Math.Sin 120
  LET nx = (cx + result * r_num)
  Math.Cos 120
  LET ny = (cy - result * r_num)
  Graphics.DrawProportional nx, ny, "4", GOLD, 0, 0.35

  Math.Sin 150
  LET nx = (cx + result * r_num)
  Math.Cos 150
  LET ny = (cy - result * r_num)
  Graphics.DrawProportional nx, ny, "5", GOLD, 0, 0.35

  Graphics.DrawProportional (cx - 4), (cy + r_num), "6", GOLD, 0, 0.4

  Math.Sin 210
  LET nx = (cx + result * r_num)
  Math.Cos 210
  LET ny = (cy - result * r_num)
  Graphics.DrawProportional nx, ny, "7", GOLD, 0, 0.35

  Math.Sin 240
  LET nx = (cx + result * r_num)
  Math.Cos 240
  LET ny = (cy - result * r_num)
  Graphics.DrawProportional nx, ny, "8", GOLD, 0, 0.35

  Graphics.DrawProportional (cx - r_num - 6), (cy - 5), "9", GOLD, 0, 0.4

  Math.Sin 300
  LET nx = (cx + result * r_num)
  Math.Cos 300
  LET ny = (cy - result * r_num)
  Graphics.DrawProportional nx, ny, "10", GOLD, 0, 0.35

  Math.Sin 330
  LET nx = (cx + result * r_num)
  Math.Cos 330
  LET ny = (cy - result * r_num)
  Graphics.DrawProportional nx, ny, "11", GOLD, 0, 0.35

  # === DECORATIVE DOTS ===
  Math.Sin 0
  LET dx = (cx + result * r_dot)
  Math.Cos 0
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 30
  LET dx = (cx + result * r_dot)
  Math.Cos 30
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 60
  LET dx = (cx + result * r_dot)
  Math.Cos 60
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 90
  LET dx = (cx + result * r_dot)
  Math.Cos 90
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 120
  LET dx = (cx + result * r_dot)
  Math.Cos 120
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 150
  LET dx = (cx + result * r_dot)
  Math.Cos 150
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 180
  LET dx = (cx + result * r_dot)
  Math.Cos 180
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 210
  LET dx = (cx + result * r_dot)
  Math.Cos 210
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 240
  LET dx = (cx + result * r_dot)
  Math.Cos 240
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 270
  LET dx = (cx + result * r_dot)
  Math.Cos 270
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 300
  LET dx = (cx + result * r_dot)
  Math.Cos 300
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  Math.Sin 330
  LET dx = (cx + result * r_dot)
  Math.Cos 330
  LET dy = (cy - result * r_dot)
  Graphics.FillCircle dx, dy, 2, GOLD

  # === GET CURRENT TIME ===
  SYSTEM.GETTIME

  # === CLOCK HANDS ===
  # Clock angles: 0=12 o'clock, clockwise
  # x = cx + r*sin(angle), y = cy - r*cos(angle)

  # Hour hand
  LET h_ang = ((hour % 12) * 30) + (minute * 0.5)
  Math.Sin h_ang
  LET hx = (cx + result * r_hour)
  Math.Cos h_ang
  LET hy = (cy - result * r_hour)

  # Hour hand triangle
  LET h_perp = (h_ang + 90)
  Math.Sin h_perp
  LET hp1x = (cx + result * 6)
  Math.Cos h_perp
  LET hp1y = (cy - result * 6)
  Math.Sin (h_ang - 90)
  LET hp2x = (cx + result * 6)
  Math.Cos (h_ang - 90)
  LET hp2y = (cy - result * 6)

  Graphics.DrawTriangle (hp1x + 1), (hp1y + 1), (hp2x + 1), (hp2y + 1), (hx + 1), (hy + 1), DARKGRAY
  Graphics.DrawTriangle hp1x, hp1y, hp2x, hp2y, hx, hy, SILVER
  Graphics.DrawLine cx, cy, hx, hy, WHITE

  # Minute hand
  LET m_ang = (minute * 6) + (second * 0.1)
  Math.Sin m_ang
  LET mx = (cx + result * r_min)
  Math.Cos m_ang
  LET my = (cy - result * r_min)

  LET m_perp = (m_ang + 90)
  Math.Sin m_perp
  LET mp1x = (cx + result * 4)
  Math.Cos m_perp
  LET mp1y = (cy - result * 4)
  Math.Sin (m_ang - 90)
  LET mp2x = (cx + result * 4)
  Math.Cos (m_ang - 90)
  LET mp2y = (cy - result * 4)

  Graphics.DrawTriangle (mp1x + 1), (mp1y + 1), (mp2x + 1), (mp2y + 1), (mx + 1), (my + 1), DARKGRAY
  Graphics.DrawTriangle mp1x, mp1y, mp2x, mp2y, mx, my, SILVER
  Graphics.DrawLine cx, cy, mx, my, WHITE

  # Second hand
  LET s_ang = (second * 6)
  Math.Sin s_ang
  LET sx = (cx + result * r_sec)
  Math.Cos s_ang
  LET sy = (cy - result * r_sec)
  Math.Sin (s_ang + 180)
  LET stx = (cx + result * 16)
  Math.Cos (s_ang + 180)
  LET sty = (cy - result * 16)

  Graphics.DrawLine stx, sty, sx, sy, RED
  Graphics.FillCircle sx, sy, 2, RED

  # === CENTER HUB ===
  Graphics.FillCircle cx, cy, 8, DARKGRAY
  Graphics.FillCircle cx, cy, 6, SILVER
  Graphics.FillCircle cx, cy, 3, GOLD
  Graphics.FillCircle cx, cy, 1, WHITE

  # === BRAND TEXT ===
  Graphics.DrawProportional (cx - 30), (cy - 35), "OMEGA", GOLD, 0, 0.3
  Graphics.DrawProportional (cx - 24), (cy + 28), "ONYX", DARKGRAY, 0, 0.25

  # === BOTTOM STATUS BAR ===
  Graphics.FillRect 0, bar_y, ww, 38, 0x0841
  Graphics.DrawLine 0, bar_y, ww, bar_y, GOLD
  Graphics.DrawLine 0, (bar_y + 1), ww, (bar_y + 1), DARKGRAY

  # Digital time
  LET h_str = hour
  IF hour < 10 THEN
    LET h_str = "0" + hour
  ENDIF
  LET m_str = minute
  IF minute < 10 THEN
    LET m_str = "0" + minute
  ENDIF
  LET s_str = second
  IF second < 10 THEN
    LET s_str = "0" + second
  ENDIF

  LET t1 = h_str + ":"
  LET t2 = t1 + m_str
  LET t3 = t2 + ":"
  LET ts = t3 + s_str

  Graphics.DrawProportional (cx - 30), (bar_y + 6), ts, GOLD, 0, 0.6

  # Date
  LET d1 = day + " / "
  LET d2 = d1 + month
  LET d3 = d2 + " / "
  LET ds = d3 + year
  Graphics.DrawProportional 10, (bar_y + 10), ds, SILVER, 0, 0.4

  # System info
  SYSTEM.TOP
  LET mem_kb = (mem_free / 1024)
  LET s1 = "MEM:" + mem_kb
  LET s2 = s1 + "K"
  Graphics.DrawString (ww - 90), (bar_y + 18), s2, DARKGRAY
RETURN
