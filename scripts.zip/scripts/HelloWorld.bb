# HelloWorld.bb - Project Blue Welcome App
SYSTEM.APPNAME "System Welcome"

LET click_count = 0
LET last_x = 0
LET last_y = 0

:onDraw
  Graphics.FillRect 0, 0, 396, 300, BLACK

  # Title
  Graphics.DrawProportional 50, 30, "Welcome to Project Blue", WHITE, 0, 0.7
  Graphics.DrawLine 40, 70, 360, 70, CYAN

  # System Stats
  SYSTEM.TOP
  Graphics.DrawString 40, 90, "Kernel: RUNNING", GREEN
  
  LET h_str1 = "Heap:  " + mem_free
  LET h_str = h_str1 + " bytes"
  Graphics.DrawString 40, 115, h_str, WHITE

  LET p_str1 = "PSRAM: " + psram_free
  LET p_str = p_str1 + " bytes"
  Graphics.DrawString 40, 135, p_str, WHITE

  LET t_str = "Tasks: " + tasks_count
  Graphics.DrawString 40, 155, t_str, WHITE

  # Chip & Uptime
  System.GetChipType 
  System.GetUptime
  LET c_str = "Chip:   " + chip_type
  Graphics.DrawString 40, 185, c_str, CYAN
  
  LET u_str1 = "Uptime: " + uptime
  LET u_str = u_str1 + "s"
  Graphics.DrawString 40, 205, u_str, CYAN

  # Interaction Area
  Graphics.FillRect 220, 90, 140, 100, DARKGRAY
  Graphics.DrawString 230, 100, "CLICK BOX", WHITE
  LET clk_str = "Clicks: " + click_count
  Graphics.DrawString 230, 125, clk_str, YELLOW
  
  LET l_str1 = "Last: " + last_x
  LET l_str2 = l_str1 + ","
  LET l_str = l_str2 + last_y
  Graphics.DrawString 230, 150, l_str, SILVER

  # Time & Date
  SYSTEM.GETTIME
  LET ti1 = hour + ":"
  LET ti2 = ti1 + minute
  LET ti3 = ti2 + ":"
  LET ti_str = ti3 + second
  Graphics.DrawString 40, 235, ti_str, YELLOW
  
  LET da1 = day + "/"
  LET da2 = da1 + month
  LET da3 = da2 + "/"
  LET da_str = da3 + year
  Graphics.DrawString 220, 235, da_str, YELLOW

  # Footer
  Graphics.DrawProportional 70, 270, "Press Escape to Close", ORANGE, 0, 0.6
RETURN

:onMouseEvent
  # box is 220,90 -> 360,190
  IF event_type = "Down" THEN
    LET last_x = event_x
    LET last_y = event_y
    Collision.Rect event_x, event_y, 1, 1, 220, 90, 140, 100
    IF collision_hit = 1 THEN
      LET click_count = click_count + 1
    ENDIF
  ENDIF
RETURN

:onKeyboardEvent
  IF event_value = "Escape" THEN
    System.Close
  ENDIF
RETURN
